# TDA-IMP-M0-002 — Repository Baseline & Technology Stack Decision v1.0

**Status:** DECISION BASELINE  
**Date:** 2026-08-14

## Decision
Use a **TypeScript modular monolith + separate notification worker**.

- Web: Next.js + TypeScript
- Database: PostgreSQL
- ORM: Prisma
- Worker: Node.js + TypeScript
- Workspace: pnpm
- Tests: Vitest + Playwright + integration tests
- Tooling: ESLint + Prettier
- Notifications: transactional outbox + async worker
- Providers: SMTP adapter + Twilio adapter
- Auth: managed provider behind application authorization; provider requires ADR if not already approved

## M0 Boundary
Create the implementation/tooling skeleton only. Do **not** implement Patient, Appointment or Notification business behavior.

## Non-Negotiables
- No speculative features.
- No silent architecture changes.
- No custom auth unless approved.
- No Redis/broker without approved requirement.
- No secrets in Git.
- No destructive Git/database operations.
- No commit unless explicitly instructed.
- Stop on source-of-truth conflict.

## Core Invariant
**Appointment + History + Audit + Notification Outbox = one database transaction.**

Provider calls occur only after commit through the notification worker.
