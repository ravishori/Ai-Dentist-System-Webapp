# DentalCare AI – Volume 4 DDD
## Domain 1 – Foundation & Identity

**Version:** 1.0  
**Date:** 14 August 2026

This domain establishes the PostgreSQL foundation for multi-tenant SaaS, identity, authorization, subscriptions, feature flags, configuration and audit.

## Tables

### `organizations`

Tenant/company master record.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| legal_name | varchar(200) | NOT NULL |  |
| display_name | varchar(200) | NOT NULL |  |
| organization_code | varchar(50) | NOT NULL | UNIQUE |
| status | varchar(30) | NOT NULL | CHECK |
| country_code | char(2) | NOT NULL | ISO-style country code |
| default_currency_code | char(3) | NOT NULL | ISO-style currency code |
| default_timezone | varchar(64) | NOT NULL | IANA timezone |
| contact_email | varchar(320) | NULL |  |
| contact_phone | varchar(30) | NULL |  |
| website_url | varchar(500) | NULL |  |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |
| deleted_at | timestamptz | NULL | Soft-delete lifecycle |

### `branches`

Physical/operational branch belonging to an organization.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_id | uuid | NOT NULL | FK organizations(id) |
| branch_code | varchar(50) | NOT NULL | UNIQUE within organization |
| name | varchar(200) | NOT NULL |  |
| status | varchar(30) | NOT NULL | CHECK |
| address_line1 | varchar(250) | NOT NULL |  |
| address_line2 | varchar(250) | NULL |  |
| city | varchar(120) | NOT NULL |  |
| state_province | varchar(120) | NULL |  |
| postal_code | varchar(30) | NULL |  |
| country_code | char(2) | NOT NULL |  |
| phone | varchar(30) | NULL |  |
| email | varchar(320) | NULL |  |
| timezone | varchar(64) | NULL | Defaults to organization timezone |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |
| deleted_at | timestamptz | NULL |  |

### `users`

Platform identity record. Does not itself grant tenant access.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| email | varchar(320) | NOT NULL | Unique according to identity policy |
| normalized_email | varchar(320) | NOT NULL | UNIQUE |
| phone_e164 | varchar(20) | NULL |  |
| display_name | varchar(200) | NOT NULL |  |
| status | varchar(30) | NOT NULL | CHECK |
| password_hash | text | NULL | Only if local-password authentication is enabled |
| email_verified_at | timestamptz | NULL |  |
| phone_verified_at | timestamptz | NULL |  |
| last_login_at | timestamptz | NULL |  |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |
| deleted_at | timestamptz | NULL |  |

### `organization_memberships`

Authorizes a user within an organization.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_id | uuid | NOT NULL | FK organizations(id) |
| user_id | uuid | NOT NULL | FK users(id) |
| status | varchar(30) | NOT NULL | CHECK |
| job_title | varchar(120) | NULL |  |
| joined_at | timestamptz | NOT NULL | DEFAULT now() |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |
| deleted_at | timestamptz | NULL |  |

### `branch_memberships`

Authorizes a user for a specific branch.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_id | uuid | NOT NULL | FK organizations(id) |
| branch_id | uuid | NOT NULL | FK branches(id) |
| user_id | uuid | NOT NULL | FK users(id) |
| status | varchar(30) | NOT NULL | CHECK |
| is_primary | boolean | NOT NULL | DEFAULT false |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |
| deleted_at | timestamptz | NULL |  |

### `roles`

Configurable authorization role.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_id | uuid | NULL | FK organizations(id); NULL may represent platform/system role |
| name | varchar(100) | NOT NULL |  |
| code | varchar(80) | NOT NULL |  |
| description | varchar(500) | NULL |  |
| scope | varchar(30) | NOT NULL | platform/organization/branch |
| is_system_role | boolean | NOT NULL | DEFAULT false |
| status | varchar(30) | NOT NULL | CHECK |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |
| deleted_at | timestamptz | NULL |  |

### `permissions`

Atomic authorization capability.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| code | varchar(150) | NOT NULL | UNIQUE |
| name | varchar(150) | NOT NULL |  |
| description | varchar(500) | NULL |  |
| resource | varchar(100) | NOT NULL |  |
| action | varchar(50) | NOT NULL |  |
| created_at | timestamptz | NOT NULL | DEFAULT now() |

### `role_permissions`

Many-to-many relationship between roles and permissions.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| role_id | uuid | NOT NULL | FK roles(id) |
| permission_id | uuid | NOT NULL | FK permissions(id) |
| created_at | timestamptz | NOT NULL | DEFAULT now() |

### `membership_roles`

Assigns organization/branch roles to memberships.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_membership_id | uuid | NULL | FK organization_memberships(id) |
| branch_membership_id | uuid | NULL | FK branch_memberships(id) |
| role_id | uuid | NOT NULL | FK roles(id) |
| created_at | timestamptz | NOT NULL | DEFAULT now() |

### `user_sessions`

Tracks authenticated sessions/devices.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| user_id | uuid | NOT NULL | FK users(id) |
| organization_id | uuid | NULL | FK organizations(id) |
| session_token_hash | text | NOT NULL | Never store raw session token |
| device_id | varchar(200) | NULL |  |
| ip_address | inet | NULL |  |
| user_agent | text | NULL |  |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| expires_at | timestamptz | NOT NULL |  |
| revoked_at | timestamptz | NULL |  |
| last_seen_at | timestamptz | NULL |  |

### `mfa_methods`

Registered multi-factor authentication methods.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| user_id | uuid | NOT NULL | FK users(id) |
| method_type | varchar(30) | NOT NULL | TOTP/WebAuthn/SMS/etc.; exact support via ADR |
| label | varchar(100) | NULL |  |
| secret_encrypted | bytea | NULL | Encrypted secret where applicable |
| credential_reference | text | NULL | Provider/WebAuthn reference where applicable |
| is_primary | boolean | NOT NULL | DEFAULT false |
| verified_at | timestamptz | NULL |  |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| revoked_at | timestamptz | NULL |  |

### `subscriptions`

Organization SaaS subscription.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_id | uuid | NOT NULL | FK organizations(id) |
| plan_code | varchar(80) | NOT NULL |  |
| status | varchar(30) | NOT NULL | CHECK |
| billing_interval | varchar(20) | NOT NULL | monthly/annual/etc. |
| started_at | timestamptz | NOT NULL |  |
| current_period_start | timestamptz | NOT NULL |  |
| current_period_end | timestamptz | NOT NULL |  |
| cancelled_at | timestamptz | NULL |  |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |

### `subscription_features`

Entitlements/limits for a subscription.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| subscription_id | uuid | NOT NULL | FK subscriptions(id) |
| feature_code | varchar(100) | NOT NULL |  |
| enabled | boolean | NOT NULL | DEFAULT true |
| usage_limit | numeric(20,4) | NULL | Optional limit |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |

### `feature_flags`

Controlled feature enablement.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_id | uuid | NULL | FK organizations(id) |
| feature_code | varchar(100) | NOT NULL |  |
| environment | varchar(30) | NOT NULL | dev/test/staging/prod |
| enabled | boolean | NOT NULL | DEFAULT false |
| rollout_percentage | numeric(5,2) | NULL | 0–100 if percentage rollout is used |
| config_json | jsonb | NULL | Validated configuration only |
| created_at | timestamptz | NOT NULL | DEFAULT now() |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |

### `organization_settings`

Versionable organization configuration.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| organization_id | uuid | NOT NULL | PK/FK organizations(id) |
| settings_json | jsonb | NOT NULL | Validated schema-controlled configuration |
| version | integer | NOT NULL | DEFAULT 1 |
| updated_by_user_id | uuid | NULL | FK users(id) |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |

### `branch_settings`

Versionable branch configuration.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| branch_id | uuid | NOT NULL | PK/FK branches(id) |
| settings_json | jsonb | NOT NULL | Validated schema-controlled configuration |
| version | integer | NOT NULL | DEFAULT 1 |
| updated_by_user_id | uuid | NULL | FK users(id) |
| updated_at | timestamptz | NOT NULL | DEFAULT now() |

### `audit_events`

Append-oriented record of significant actions.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_id | uuid | NULL | FK organizations(id) |
| branch_id | uuid | NULL | FK branches(id) |
| actor_user_id | uuid | NULL | FK users(id) |
| event_type | varchar(100) | NOT NULL |  |
| resource_type | varchar(100) | NULL |  |
| resource_id | uuid | NULL |  |
| action | varchar(50) | NOT NULL |  |
| occurred_at | timestamptz | NOT NULL | DEFAULT now() |
| ip_address | inet | NULL |  |
| user_agent | text | NULL |  |
| correlation_id | uuid | NULL |  |
| metadata_json | jsonb | NULL | Avoid unnecessary sensitive data |

### `security_events`

Security-specific events requiring monitoring.

| Column | Type | Null | Constraints/Notes |
|---|---|---|---|
| id | uuid | NOT NULL | PK |
| organization_id | uuid | NULL | FK organizations(id) |
| user_id | uuid | NULL | FK users(id) |
| event_type | varchar(100) | NOT NULL |  |
| severity | varchar(20) | NOT NULL | CHECK |
| ip_address | inet | NULL |  |
| user_agent | text | NULL |  |
| occurred_at | timestamptz | NOT NULL | DEFAULT now() |
| metadata_json | jsonb | NULL | Minimize sensitive content |
| resolved_at | timestamptz | NULL |  |
| resolved_by_user_id | uuid | NULL | FK users(id) |

## Tenant Isolation

- Every tenant-owned record must have an enforceable ownership path to organization_id.
- Never trust client tenant IDs.
- Consider PostgreSQL RLS for high-assurance isolation.
- Cross-tenant administration must be explicit and audited.

## Controlled Roadmap

- Domain 1 – Foundation & Identity – CURRENT
- Domain 2 – Patient & EHR
- Domain 3 – Appointments & Scheduling
- Domain 4 – Clinical Dentistry & Odontogram
- Domain 5 – Treatment Planning & Consent
- Domain 6 – Billing, Payments & Insurance
- Domain 7 – Imaging & Documents
- Domain 8 – Dental Laboratory
- Domain 9 – Inventory & Procurement
- Domain 10 – Sterilization, Assets & Maintenance
- Domain 11 – CRM, Recall & Patient Engagement
- Domain 12 – AI & Knowledge Hub
- Domain 13 – Notifications & Integrations
- Domain 14 – Analytics & Reporting
- Domain 15 – Platform Governance, Retention & Advanced Audit

## Cursor Rules

- Do not implement later-domain tables early.
- Use migrations and tests.
- Enforce server-side authorization and tenant isolation.
- Never store raw tokens/secrets.
- Stop and report architecture conflicts.
