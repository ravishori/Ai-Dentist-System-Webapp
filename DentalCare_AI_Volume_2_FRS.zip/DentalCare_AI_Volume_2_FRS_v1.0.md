# DentalCare AI
## Volume 2 – Functional Requirements Specification (FRS)

**Version:** 1.0  
**Date:** 14 August 2026  
**Purpose:** Implementation-oriented functional requirements derived from the BRD.

## 1. FRS Conventions

- Requirement IDs use MOD-FR-NNN.
- Priority: MUST / SHOULD / COULD.
- Requirements should be traceable to UI, API, database and tests.
- AI clinical functions require appropriate human review.

## 3. Identity, Tenant & User Administration

**Module code:** IAM

- IAM-FR-001 MUST – Platform administrators shall create and suspend organizations.
- IAM-FR-002 MUST – Organization administrators shall create branches, users, roles, and permissions within authorized scope.
- IAM-FR-003 MUST – The system shall support configurable MFA.
- IAM-FR-004 MUST – The system shall enforce tenant and branch isolation for data access.
- IAM-FR-005 MUST – Custom roles shall be composable from granular permissions.
- IAM-FR-006 SHOULD – SSO/OIDC integration shall be supported for enterprise plans.
- IAM-FR-007 MUST – Permission changes shall be audited.

## 4. Patient Registration & EHR

**Module code:** PAT

- PAT-FR-001 MUST – Staff shall create and update patient demographic profiles.
- PAT-FR-002 MUST – The system shall generate a unique Patient ID.
- PAT-FR-003 MUST – Duplicate detection shall use configurable matching rules such as mobile, email, name, and date of birth.
- PAT-FR-004 MUST – The system shall capture medical history, allergies, medications, emergency contacts, and dental history.
- PAT-FR-005 MUST – Family/dependent relationships shall be supported.
- PAT-FR-006 MUST – Patient records shall display a chronological timeline of appointments, treatments, notes, prescriptions, payments, images, documents, and communications.
- PAT-FR-007 MUST – Authorized users shall upload and retrieve patient documents with access control.
- PAT-FR-008 SHOULD – Configurable intake forms and patient questionnaires shall be supported.
- PAT-FR-009 MUST – Patient data export shall respect authorization and audit requirements.

## 5. Appointments, Calendar & Queue

**Module code:** APT

- APT-FR-001 MUST – Authorized users shall create, reschedule, cancel, confirm, check in, start, complete, and mark no-show appointments.
- APT-FR-002 MUST – Scheduling shall consider dentist, chair, room, equipment, duration, branch hours, and configured buffers.
- APT-FR-003 MUST – Double booking shall be prevented unless an explicit clinic rule permits it.
- APT-FR-004 MUST – Waitlists shall capture preferred time windows and notify eligible patients when slots open.
- APT-FR-005 MUST – QR or staff-assisted check-in shall update queue status.
- APT-FR-006 MUST – The queue shall show current patient status and estimated waiting time where calculable.
- APT-FR-007 SHOULD – AI scheduling shall recommend suitable slots based on configured rules and historical patterns.
- APT-FR-008 MUST – Appointment reminders shall support configurable schedules and channels.
- APT-FR-009 SHOULD – Calendar synchronization shall support approved external calendar providers.

## 6. Clinical Examination & Digital Odontogram

**Module code:** CLN

- CLN-FR-001 MUST – Dentists shall open a clinical encounter from an appointment or patient record.
- CLN-FR-002 MUST – The system shall provide adult and pediatric FDI tooth numbering.
- CLN-FR-003 MUST – Users shall chart tooth conditions and surfaces using configurable clinical states.
- CLN-FR-004 MUST – The system shall capture chief complaint, history, examination findings, diagnosis, assessment, and plan.
- CLN-FR-005 MUST – Clinical notes shall support templates and version history.
- CLN-FR-006 MUST – Finalized clinical records shall not be silently overwritten.
- CLN-FR-007 SHOULD – Voice dictation and AI draft notes shall be available as controlled features.
- CLN-FR-008 MUST – AI-generated clinical content shall require clinician review before finalization.

## 7. Treatment Planning & Consent

**Module code:** TRT

- TRT-FR-001 MUST – Dentists shall create treatment plans linked to diagnoses and affected teeth where applicable.
- TRT-FR-002 MUST – Treatment plans shall support phases, procedures, estimated duration, assigned provider, and status.
- TRT-FR-003 MUST – The system shall support multiple plan options such as Good/Better/Best.
- TRT-FR-004 MUST – Patients shall be able to receive a treatment estimate through approved channels.
- TRT-FR-005 MUST – Authorized users shall record patient approval or rejection.
- TRT-FR-006 MUST – Procedure-specific consent forms shall be selectable and versioned.
- TRT-FR-007 MUST – Digital consent shall record signer, timestamp, document version, and audit metadata.

## 8. Billing, Payments & Insurance

**Module code:** FIN

- FIN-FR-001 MUST – Users shall create estimates and invoices from configured services and treatment plans.
- FIN-FR-002 MUST – Invoice numbering shall follow tenant configuration and uniqueness rules.
- FIN-FR-003 MUST – The system shall support configurable taxes, discounts, advances, packages, refunds, credit notes, and debit notes.
- FIN-FR-004 MUST – Payments shall support multiple methods and partial payments.
- FIN-FR-005 MUST – Refunds shall reference the original transaction and require configured authorization.
- FIN-FR-006 SHOULD – Payment gateway integrations shall support online payment links and reconciliation.
- FIN-FR-007 SHOULD – Insurance workflows shall track policy, pre-authorization, claim, rejection, and settlement states.
- FIN-FR-008 MUST – Financial records shall be immutable through controlled reversal/credit workflows rather than destructive edits.

## 9. Imaging, Documents & PACS

**Module code:** IMG

- IMG-FR-001 MUST – Authorized users shall upload clinical images and supported diagnostic files.
- IMG-FR-002 MUST – Files shall be linked to patient, encounter, procedure, uploader, and timestamp metadata.
- IMG-FR-003 SHOULD – DICOM studies shall be viewable through an integrated or approved viewer.
- IMG-FR-004 SHOULD – Image annotation and measurement shall be supported.
- IMG-FR-005 MUST – File access shall be permission controlled and auditable.
- IMG-FR-006 MUST – Uploaded files shall undergo configured security/malware checks.

## 10. Dental Laboratory

**Module code:** LAB

- LAB-FR-001 MUST – Users shall create lab cases linked to patient and treatment plan.
- LAB-FR-002 MUST – Lab orders shall capture material, shade, tooth numbers, due date, instructions, attachments, and cost.
- LAB-FR-003 MUST – Lab cases shall use configurable lifecycle statuses.
- LAB-FR-004 SHOULD – STL and other digital dentistry files shall be securely exchanged.
- LAB-FR-005 MUST – Delayed or overdue cases shall trigger configurable alerts.
- LAB-FR-006 MUST – Case revisions and remakes shall be traceable.

## 11. Inventory, Procurement & Sterilization

**Module code:** INV

- INV-FR-001 MUST – Inventory items shall support SKU, unit, stock level, batch, expiry, supplier, and location data.
- INV-FR-002 MUST – Stock movements shall record purchase, consumption, transfer, return, adjustment, damage, expiry, and disposal.
- INV-FR-003 MUST – Negative stock shall be prevented unless explicitly configured.
- INV-FR-004 MUST – Low-stock and expiry alerts shall be configurable.
- INV-FR-005 SHOULD – Procedures may consume predefined material quantities automatically.
- INV-FR-006 MUST – Purchase requisitions, purchase orders, and goods receipt shall be traceable.
- INV-FR-007 MUST – Implant records shall support batch/lot traceability to the patient.
- INV-FR-008 MUST – Sterilization cycles shall capture equipment, operator, parameters, indicators, outcome, and timestamp.

## 12. Asset & Maintenance Management

**Module code:** AST

- AST-FR-001 MUST – Equipment records shall capture serial number, location, warranty, AMC, calibration, and status.
- AST-FR-002 MUST – Preventive maintenance schedules shall generate due alerts.
- AST-FR-003 MUST – Repairs shall capture issue, service provider, downtime, parts, cost, and resolution.
- AST-FR-004 SHOULD – Equipment utilization and downtime dashboards shall be available.

## 13. CRM, Recall & Patient Engagement

**Module code:** CRM

- CRM-FR-001 MUST – Leads shall be created, assigned, qualified, converted, or closed.
- CRM-FR-002 MUST – Patient communication preferences shall be stored and enforced.
- CRM-FR-003 MUST – Recall schedules shall be configurable by treatment, patient, or clinic rule.
- CRM-FR-004 MUST – Reminder delivery status shall be recorded.
- CRM-FR-005 SHOULD – Loyalty points, referrals, and memberships shall be configurable.
- CRM-FR-006 SHOULD – Campaigns shall support audience segmentation, approval, scheduling, and performance tracking.

## 14. AI Platform & Automation

**Module code:** AI

- AI-FR-001 MUST – All AI requests shall pass through a controlled AI service/gateway.
- AI-FR-002 MUST – AI features shall enforce tenant and user authorization.
- AI-FR-003 MUST – AI-generated clinical documentation shall be marked as draft until approved.
- AI-FR-004 MUST – AI shall not autonomously prescribe or make irreversible clinical decisions.
- AI-FR-005 SHOULD – The platform shall support configurable model providers.
- AI-FR-006 SHOULD – RAG shall retrieve only authorized knowledge sources.
- AI-FR-007 MUST – AI prompts, outputs, approvals, and failures shall be logged according to configurable privacy policy.
- AI-FR-008 SHOULD – AI quality evaluation shall support accuracy, hallucination, latency, cost, and user-feedback metrics.

## 15. Patient Mobile App & Portal

**Module code:** MOB

- MOB-FR-001 MUST – Patients shall securely view and manage eligible appointments.
- MOB-FR-002 MUST – Patients shall view invoices, receipts, prescriptions, consents, and eligible clinical documents.
- MOB-FR-003 MUST – Patients shall receive push notifications subject to consent and settings.
- MOB-FR-004 SHOULD – Patients shall complete intake forms and consent remotely.
- MOB-FR-005 SHOULD – Patients shall communicate securely with clinic staff subject to clinic policies.
- MOB-FR-006 SHOULD – Teleconsultation links shall be available for eligible appointments.

## 16. Dentist & Staff Workspaces

**Module code:** STF

- STF-FR-001 MUST – Dentist dashboards shall prioritize appointments, patient alerts, clinical work, and tasks.
- STF-FR-002 MUST – Reception dashboards shall prioritize queue, scheduling, payments, and communication.
- STF-FR-003 MUST – Assistant dashboards shall prioritize preparation, sterilization, tasks, and inventory.
- STF-FR-004 MUST – Staff tasks shall support assignment, priority, due date, status, comments, and audit trail.

## 17. Reports & Business Intelligence

**Module code:** BI

- BI-FR-001 MUST – Authorized users shall access dashboards according to role and tenant scope.
- BI-FR-002 MUST – Reports shall support filters, date ranges, grouping, sorting, and export.
- BI-FR-003 SHOULD – Custom report definitions shall be saved and shared.
- BI-FR-004 SHOULD – Scheduled reports shall be delivered through approved channels.
- BI-FR-005 SHOULD – AI summaries and forecasts shall identify assumptions and uncertainty.

## 18. Notifications & Communications

**Module code:** NTF

- NTF-FR-001 MUST – A centralized notification service shall manage SMS, email, WhatsApp, push, and in-app messages where configured.
- NTF-FR-002 MUST – Message templates shall support tenant branding and localization.
- NTF-FR-003 MUST – Delivery status and failures shall be recorded.
- NTF-FR-004 MUST – Communication preferences and opt-out rules shall be respected.
- NTF-FR-005 SHOULD – Retry policies shall handle transient delivery failures.

## 19. Search & Global Navigation

**Module code:** SRCH

- SRCH-FR-001 MUST – Authorized users shall search patients, appointments, invoices, lab cases, inventory, and documents.
- SRCH-FR-002 MUST – Search results shall respect tenant, branch, role, and record permissions.
- SRCH-FR-003 SHOULD – Global search shall support typo-tolerant and semantic assistance without bypassing access controls.

## 20. Workflow & Rules Engine

**Module code:** WF

- WF-FR-001 SHOULD – Authorized administrators shall define configurable workflows from approved triggers, conditions, actions, and approvals.
- WF-FR-002 MUST – Workflow execution shall be idempotent where retries are possible.
- WF-FR-003 MUST – Workflow failures shall be logged and surfaced for operational recovery.
- WF-FR-004 MUST – High-risk actions shall require configured approval steps.

## 21. API & Integration Platform

**Module code:** API

- API-FR-001 MUST – APIs shall be versioned and documented using OpenAPI.
- API-FR-002 MUST – APIs shall authenticate and authorize every protected request.
- API-FR-003 MUST – APIs shall support pagination, filtering, validation, standardized errors, and rate limiting.
- API-FR-004 SHOULD – Webhooks shall notify approved external systems of selected events.
- API-FR-005 SHOULD – Integration adapters shall isolate provider-specific logic from core business logic.

## 22. Security, Privacy & Audit

**Module code:** SEC

- SEC-FR-001 MUST – RBAC shall be enforced server-side.
- SEC-FR-002 MUST – Sensitive data shall be encrypted in transit and at rest using approved mechanisms.
- SEC-FR-003 MUST – Audit logs shall record significant security, clinical, financial, consent, export, and administrative events.
- SEC-FR-004 MUST – Sessions shall support timeout and revocation.
- SEC-FR-005 MUST – Data export, correction, retention, and deletion workflows shall be configurable according to applicable legal requirements.
- SEC-FR-006 MUST – Security events shall be monitored and alertable.

## 23. SaaS Administration & Subscriptions

**Module code:** SaaS

- SaaS-FR-001 MUST – Platform administrators shall provision organizations and subscriptions.
- SaaS-FR-002 MUST – Subscription plans shall support configurable feature and usage limits.
- SaaS-FR-003 MUST – Feature flags shall allow controlled enablement by tenant, plan, or environment.
- SaaS-FR-004 SHOULD – White-label branding and custom domains shall be supported for eligible plans.
- SaaS-FR-005 MUST – Tenant lifecycle actions shall be auditable.

## Global and Cross-Module Workflows

- New Patient: registration → duplicate check → intake → appointment → check-in → clinical encounter → diagnosis → treatment plan → consent → treatment → billing → payment → follow-up → recall.
- Treatment: diagnosis → plan → approval → scheduling → resource reservation → procedure → inventory/lab/imaging → invoice → payment → follow-up.
- Lab: case → files/instructions → acceptance → production → dispatch → receipt → fitting → closure/remake.
- AI Scribe: encounter → transcription → draft → dentist review → approval → final record → audit.

## Acceptance Criteria Framework

A feature is complete when requirements, workflow, validation, permissions, audit, tests, UI states, API contracts and deployment verification are satisfied. Clinical AI additionally requires safety controls and human approval.

## Document Suite

- Volume 1 – BRD
- Volume 2 – FRS
- Volume 3 – TDD
- Volume 4 – Database Design
- Volume 5 – API Specification
- Volume 6 – UI/UX Specification
- Volume 7 – AI Architecture & Governance
- Volume 8 – DevOps & Infrastructure
- Volume 9 – QA & Testing Strategy
- Volume 10 – Claude AI Master Build Guide
