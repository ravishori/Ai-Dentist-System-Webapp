# DentalCare AI — Source-of-Truth Manifest
Version: 1.0
Status: REVIEW

| Document ID | Document | Version | Status | Authority |
|---|---|---:|---|---|
| TDA-GOV-SOT-001 | Source-of-Truth Policy | 1.0 | APPROVED/REVIEW | Governance |
| TDA-GOV-CUR-001 | Cursor Project Rules | 1.0 | APPROVED/REVIEW | Governance |
| TDA-GOV-CMP-001 | Change Management Policy | 1.0 | APPROVED/REVIEW | Governance |
| TDA-API-001 | API Architecture & Standards | 1.0 | REVIEW | Architecture |
| TDA-API-PAT-001 | Patient API Specification | 1.0 | REVIEW | API |
| TDA-API-APT-001 | Appointment API Specification | 1.0 | REVIEW | API |
| TDA-API-NOTIF-001 | Notification API & Worker Specification | 1.0 | REVIEW | API |
| TDA-SEC-001 | Security & Privacy Architecture | 1.0 | REVIEW | Security |
| TDA-QA-001 | Quality Assurance & Test Strategy | 1.0 | REVIEW | QA |
| TDA-IMP-001 | Cursor Implementation & Delivery Plan | 1.0 | REVIEW | Implementation |
| TDA-IMP-M0-001 | Repository & Tooling Baseline | 1.0 | READY | Implementation |

Rule: implementation must use the highest-authority approved document available. Conflicts are STOP conditions.
